package org.sopt.appjam.went.Controller;

/**
 * Created by NOEP on 15. 7. 1..
 */
import android.widget.ImageView;
import android.widget.TextView;

/**
 * ViewHolder
 */
public class ViewHolder {

    ImageView imageView_downImage;
    TextView textView_title;
    TextView textView_maxPrice;

}
