package org.sopt.appjam.went.Model;

/**
 * Created by NOEP on 15. 7. 8..
 */
public class Depth1_item {

    public int motherid ;

    public String title;
    public String path;
    public String mintime;
    public String maxtime;
    public Double lat;
    public Double lon;
    public String address;
    public String userid;










        }
