package org.sopt.appjam.went.Model;

/**
 * Created by NOEP on 15. 7. 9..
 */
public class Depth2_item {


    public int motherid ;
    public int secondid;

    public String title;
    public String path;
    public String content;
    public Double lat;
    public Double lon;
    public String address;
    public String userid;
    public String time;

    public String timestamp;














}
