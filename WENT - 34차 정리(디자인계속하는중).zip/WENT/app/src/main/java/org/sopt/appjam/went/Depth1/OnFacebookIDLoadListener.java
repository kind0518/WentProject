package org.sopt.appjam.went.Depth1;

/**
 * Created by NOEP on 15. 7. 8..
 */
public interface OnFacebookIDLoadListener {

    public void onFacebookIDLoaded(String facebook_id);
}
