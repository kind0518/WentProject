package org.sopt.appjam.went.Model;

/**
 * Created by NOEP on 15. 7. 6..
 */
public class Photo {

    public int id;
    public String title;
    public String content;
}
